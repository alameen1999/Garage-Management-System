import EmployeeDetails from "../components/EmployeeDetails/EmployeeDetails.js/EmployeeDetails"

const EmployeeDisplay = () => {
    return <EmployeeDetails/>
};

export default EmployeeDisplay;