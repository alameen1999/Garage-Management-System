import Userloggedin from "../components/Loggedin/Userloggedin";

const Loggedin = () => {
  return <Userloggedin />;
};

export default Loggedin;
